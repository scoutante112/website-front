export const config = {
  apilink: 'https://beta-api.bagou450.com/api/client/web',
  privateapilink: 'https://beta-api.bagou450.com/api/client/web',
  iconlink: 'https://beta-api.bagou450.com',
  privateiconlink: 'https://beta-api.bagou450.com'

};
