import React from 'react';

export default function Projects() {
  return <p>Projects</p>;
}
