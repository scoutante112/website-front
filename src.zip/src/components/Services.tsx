import React from 'react';

export default function Services() {
  return <p>Services</p>;
}
